# Freedom 2 — AU/VST3 native porting plan (design only)

1. Define stable typed parameter identifiers, ranges, defaults, units and normalized mappings.
2. Reimplement DSP in portable C++ with a deterministic `prepare(sampleRate, blockSize)` / `process(buffer, MIDI)` API.
3. Split allocation and preparation from realtime processing; eliminate per-block allocations, locks, browser APIs and UI calls from audio thread.
4. Add MIDI 1.0/2.0 event queue with sample offsets, voice lifecycle and note identity; map sustain, aftertouch, pitch bend.
5. Add host parameter automation with sample-accurate ramps, preset state serialization and migration.
6. Wrap core in JUCE or another appropriately licensed AU/VST3 framework; test AU validation, VST3 validator and DAW hosts.
7. Profile DSP, denormal handling, silence behavior, 44.1/48/96 kHz and varying buffer sizes.
8. Independently validate commercial redistribution rights for all code and assets before shipping.

**Current status:** Browser AudioWorklet DSP is JavaScript. It is not a native plugin or a drop-in AU/VST3 core.
