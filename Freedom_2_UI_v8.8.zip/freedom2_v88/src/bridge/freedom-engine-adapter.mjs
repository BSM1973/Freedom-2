// Browser-side host adapter; intentionally no DOM/UI dependency.
import {PROCESSOR_NAME,sanitizeParameters,normalizeNoteEvent} from './parameter-contract.mjs';
export class FreedomEngineAdapter {
  #context; #node; #limiter; #onDiagnostics; #active = false;
  constructor({context, onDiagnostics=()=>{}}={}) {
    if (!context?.audioWorklet) throw new Error('An AudioContext with AudioWorklet is required');
    this.#context=context;this.#onDiagnostics=onDiagnostics;
  }
  async initialize(processorUrl) {
    if(this.#node) return;
    await this.#context.audioWorklet.addModule(processorUrl);
    this.#node=new AudioWorkletNode(this.#context,PROCESSOR_NAME,{outputChannelCount:[2]});
    this.#limiter=this.#context.createDynamicsCompressor();
    this.#limiter.threshold.value=-10;this.#limiter.ratio.value=8;
    this.#limiter.attack.value=.003;this.#limiter.release.value=.12;
    this.#node.port.onmessage=event=>{if(event.data?.type==='diagnostics')this.#onDiagnostics(event.data)};
    this.#node.connect(this.#limiter);this.#limiter.connect(this.#context.destination);
    this.#active=true;
  }
  async resume(){if(!this.#node)throw new Error('Initialize the engine first');await this.#context.resume();this.#active=true}
  setParameters(source){this.#send({type:'params',values:sanitizeParameters(source)})}
  noteOn(note,velocity=100,channel=1,id){this.#send(normalizeNoteEvent({type:'on',note,velocity,channel,id}))}
  noteOff(note,channel=1,id){this.#send(normalizeNoteEvent({type:'off',note,channel,id}))}
  pitchBend(value){this.#send({type:'bend',value:Number(value)||0})}
  modWheel(value){this.#send({type:'mod',value:Number(value)||0})}
  sustain(channel,down){this.#send({type:'sustain',channel,down:!!down})}
  channelPressure(channel,value){this.#send({type:'channelpressure',channel,value})}
  polyPressure(id,value){this.#send({type:'pressure',id:String(id),value})}
  panic(){this.#send({type:'panic'})}
  async suspend(){this.panic();await this.#context.suspend();this.#active=false}
  dispose(){this.panic();this.#node?.disconnect();this.#limiter?.disconnect();this.#node=null;this.#active=false}
  get active(){return this.#active}
  #send(message){if(!this.#node)throw new Error('Engine not initialized');this.#node.port.postMessage(message)}
}
