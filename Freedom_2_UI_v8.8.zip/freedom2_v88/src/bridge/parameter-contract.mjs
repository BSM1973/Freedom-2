// Single source of truth for the modular browser bridge.
import contract from './parameter-contract.json' with { type: 'json' };
export const PROCESSOR_NAME = contract.processor;
export const PARAMETER_IDS = Object.freeze(contract.parameters.map(p=>p.id));
export const EVENT_TYPES = Object.freeze([...contract.events.toProcessor]);
export function sanitizeParameters(source) {
  const values = {};
  for (const id of PARAMETER_IDS) {
    const n = Number(source?.[id]);
    if (Number.isFinite(n)) values[id] = n;
  }
  return values;
}
export function normalizeNoteEvent(event) {
  if (!event || !['on','off'].includes(event.type)) throw new TypeError('Invalid note event');
  const channel = Math.max(1, Math.min(16, Math.trunc(Number(event.channel) || 1)));
  const note = Math.max(0, Math.min(127, Math.trunc(Number(event.note) || 0)));
  return {type:event.type, id:String(event.id ?? `host:${channel}:${note}`), note,
    velocity:Math.max(0,Math.min(127,Math.trunc(Number(event.velocity) || 0))),channel};
}
