# Freedom 2 v8.8 — Compilation Apple Silicon (ARM64)

**Livrable : sources JUCE/C++ et script de compilation, pas encore de plugin compilé.**

## Prérequis
- Mac M1/M2/M3/M4/M5, macOS 11 ou plus récent.
- Xcode complet (App Store), ouvert au moins une fois ; accepter sa licence.
- CMake (`brew install cmake`) et Git.
- JUCE téléchargé depuis son dépôt officiel et utilisé conformément à sa licence : https://github.com/juce-framework/JUCE

## Installation / compilation
Ouvrir Terminal, puis :

```bash
xcode-select --install   # uniquement si les outils ne sont pas déjà installés
brew install cmake git   # uniquement si Homebrew est installé
mkdir -p "$HOME/Developer"
git clone --depth 1 https://github.com/juce-framework/JUCE.git "$HOME/Developer/JUCE"
```

Décompresser `Freedom_2_UI_v8.8.zip`, aller dans le dossier `freedom2_v88`, puis :

```bash
export JUCE_DIR="$HOME/Developer/JUCE"
bash scripts/build_apple_silicon.sh
```

Si JUCE existe déjà, ne pas le cloner : pointer `JUCE_DIR` vers son dossier. Le script vérifie les outils, force l'architecture `arm64`, construit les formats AU/VST3/Standalone et exécute CTest. Il affiche les chemins exacts des produits ; **ne pas supposer leur existence avant une compilation réussie**.

## Installer pour un test local
Après avoir obtenu les chemins des fichiers dans le dossier `build-apple-silicon`, copier le bundle `.component` dans `~/Library/Audio/Plug-Ins/Components/` et le `.vst3` dans `~/Library/Audio/Plug-Ins/VST3/`. Ne copier que les bundles générés. Relancer les STAN / effectuer un rescan. Pour l'AU : `auval -v aumu Frd2 BSM1` (si enregistré par le système). Vérifier dans Ableton Live et Logic Pro, puis Liberty DAW.

## Vérifications essentielles
- Ouverture dans le DAW et sortie sonore, notes MIDI, sustain, Pitch Bend et PANIC.
- Clavier visible sur chaque onglet ; rack d'effets seulement dans EFFECTS.
- 100 presets générés, recherche, favoris, sauvegarde/rappel dans un projet hôte.
- Fréquences 44,1/48/96 kHz, buffers 64/128/512, 2 instances simultanées, fermeture/réouverture.
- Signature, notarisation et licences JUCE/tiers **avant toute distribution**.

## Limitations
Le projet JUCE n'a pas pu être compilé dans l'environnement Linux de préparation. Il peut nécessiter des corrections de compatibilité JUCE sur le Mac. Le moteur DSP C++ est distinct du prototype HTML. Aucune garantie de fonctionnement AU/VST3 avant tests réels.
