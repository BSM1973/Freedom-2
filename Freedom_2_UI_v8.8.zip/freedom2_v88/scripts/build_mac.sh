#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then echo "This AU/VST3 validation script requires macOS" >&2; exit 2; fi
command -v cmake >/dev/null || { echo "Install CMake" >&2; exit 2; }
command -v xcodebuild >/dev/null || { echo "Install Xcode" >&2; exit 2; }
: "${JUCE_DIR:?Set JUCE_DIR to an existing JUCE source checkout}"
[[ -f "$JUCE_DIR/CMakeLists.txt" ]] || { echo "Invalid JUCE_DIR: $JUCE_DIR" >&2; exit 2; }
cmake -S "$ROOT/plugin" -B "$ROOT/build-macos" -DJUCE_DIR="$JUCE_DIR" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build "$ROOT/build-macos" --config Release --parallel 4
ctest --test-dir "$ROOT/build-macos" -C Release --output-on-failure
printf '\nNative build products:\n'
find "$ROOT/build-macos" \( -name '*.component' -o -name '*.vst3' -o -name 'Freedom 2.app' \) -print
printf '\nRun host validation checklist in README.md; do not assume DAW compatibility from compilation alone.\n'
