#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fail(){ printf '\nERREUR : %s\n' "$*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail "Ce script doit être exécuté sur macOS."
[[ "$(uname -m)" == arm64 ]] || fail "Mac Apple Silicon ARM64 requis (détecté : $(uname -m))."
command -v xcodebuild >/dev/null || fail "Installe Xcode depuis l'App Store."
command -v cmake >/dev/null || fail "Installe CMake (brew install cmake)."
command -v git >/dev/null || fail "Installe les outils de développement Xcode (xcode-select --install)."
xcodebuild -version || fail "Active Xcode : sudo xcode-select -s /Applications/Xcode.app/Contents/Developer ; sudo xcodebuild -license accept"
[[ -n "${JUCE_DIR:-}" ]] || fail "Définis JUCE_DIR, par exemple : export JUCE_DIR=\"$HOME/Developer/JUCE\""
[[ -f "$JUCE_DIR/CMakeLists.txt" ]] || fail "JUCE introuvable dans JUCE_DIR=$JUCE_DIR"
BUILD="$ROOT/build-apple-silicon"
printf '\n=== Freedom 2 v8.8 : Apple Silicon ARM64 ===\n'
printf 'JUCE : %s\nBuild : %s\n' "$JUCE_DIR" "$BUILD"
cmake -S "$ROOT/plugin" -B "$BUILD" -G Xcode -DJUCE_DIR="$JUCE_DIR" -DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0 -DBUILD_TESTING=ON
cmake --build "$BUILD" --config Release --parallel 4
ctest --test-dir "$BUILD" -C Release --output-on-failure
printf '\n=== Produits générés ===\n'
find "$BUILD" \( -name '*.component' -o -name '*.vst3' -o -name 'Freedom 2.app' \) -print
printf '\n=== Vérification des architectures ===\n'
while IFS= read -r f; do
  [[ -d "$f" ]] || continue
  binary="$(find "$f/Contents/MacOS" -type f -maxdepth 1 2>/dev/null | head -1 || true)"
  if [[ -n "$binary" ]]; then printf '%s : ' "$f"; lipo -archs "$binary" || true; fi
done < <(find "$BUILD" \( -name '*.component' -o -name '*.vst3' -o -name 'Freedom 2.app' \) -print)
printf '\nCompilation terminée. Ne pas distribuer sans signature/notarisation et validation des licences.\n'
