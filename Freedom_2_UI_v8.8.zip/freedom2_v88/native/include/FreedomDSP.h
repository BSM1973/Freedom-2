#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace liberty {
class FreedomDSP final {
public:
  static constexpr int MaxVoices = 16;
  enum class Wave : int { Saw=0, Square=1, Triangle=2, Sine=3 };
  struct Oscillator { bool enabled = true; Wave wave = Wave::Saw; float level = 0.3f; int octave = 0; int semitone = 0; float fineCents = 0.0f; };
  enum class FilterMode : int { LP24=0, LP12=1, HP24=2, HP12=3, BP12=4, Notch=5 };
  enum class LFOWave : int { Sine=0, Triangle=1, Saw=2, Square=3, ReverseSaw=4 };
  struct LFO { float rateHz=1.0f, depth=0.0f; LFOWave wave=LFOWave::Sine; };
  struct Route { int source=0, destination=0; float amount=0.0f; }; // sources 1..3 LFO, 4 mod wheel, 5 pressure, 6 velocity; destinations 1 cutoff, 2 pitch, 3 amp
  struct Parameters {
    std::array<Oscillator,3> osc{};
    float attackSeconds = 0.01f, decaySeconds = 0.15f, sustain = 0.7f, releaseSeconds = 0.25f;
    float cutoffHz = 12000.0f, masterGain = 0.25f, bendRangeSemitones = 2.0f;
    float resonance=0.2f; FilterMode filterMode=FilterMode::LP12;
    std::array<LFO,3> lfos{}; std::array<Route,8> matrix{};
    bool syncOsc2=false, syncOsc3=false;
    struct Chorus { bool enabled=false; float rateHz=0.8f, depthMs=3.5f, mix=0.25f; } chorus{};
    struct Drive { bool enabled=false; float amount=0.35f, tone=0.65f, mix=0.35f; } drive{};
    bool driveBeforeChorus=false;
  };
  explicit FreedomDSP(double sampleRate = 48000.0) noexcept;
  void prepare(double sampleRate) noexcept;
  void setParameters(const Parameters& params) noexcept;
  const Parameters& parameters() const noexcept { return params_; }
  void noteOn(int channel, int note, int velocity) noexcept;
  void noteOff(int channel, int note) noexcept;
  void sustain(int channel, bool down) noexcept;
  void pitchBend(int channel, float normalized) noexcept;
  void allNotesOff(int channel) noexcept;
  void modWheel(int channel, float normalized) noexcept;
  void channelPressure(int channel, float normalized) noexcept;
  void panic() noexcept;
  void process(float* left, float* right, std::size_t frames) noexcept;
  int activeVoices() const noexcept;
  double sampleRate() const noexcept { return sampleRate_; }
private:
  enum class Stage : std::uint8_t { Off, Attack, Decay, Sustain, Release };
  struct Voice {
    Stage stage = Stage::Off;
    int channel = 0, note = 0;
    float velocity = 0, envelope = 0, lowpass = 0;
    struct FilterMemory { double x1=0,x2=0,y1=0,y2=0; };
    std::array<FilterMemory,2> filter{};
    std::array<double,3> phase{};
    bool heldByPedal = false;
    std::uint64_t age = 0;
  };
  static float waveform(Wave wave, double phase) noexcept;
  void releaseVoice(Voice& v) noexcept;
  std::array<Voice,MaxVoices> voices_{};
  std::array<bool,16> pedal_{};
  std::array<float,16> bend_{};
  std::array<float,16> mod_{}, pressure_{};
  std::array<double,3> lfoPhase_{};
  // Fixed-size, allocation-free delay storage: supports up to 384 kHz.
  static constexpr std::size_t DelaySize=32768;
  std::array<float,DelaySize> chorusLeft_{}, chorusRight_{};
  std::size_t chorusWrite_=0;
  double chorusPhase_=0.0;
  float driveToneLeft_=0.0f, driveToneRight_=0.0f;
  void applyChorus(float& l,float& r) noexcept;
  void applyDrive(float& l,float& r) noexcept;
  Parameters params_{};
  double sampleRate_ = 48000.0;
  std::uint64_t age_ = 0;
};
}
