#include "FreedomDSP.h"
#include <array>
#include <cassert>
#include <cmath>
#include <iostream>
int main(){
  liberty::FreedomDSP synth(48000);
  auto p=synth.parameters();p.osc[0].wave=liberty::FreedomDSP::Wave::Sine;p.osc[1].enabled=false;p.osc[2].enabled=false;synth.setParameters(p);
  std::array<float,256> l{},r{};
  synth.noteOn(0,60,100);assert(synth.activeVoices()==1);
  synth.process(l.data(),r.data(),l.size());
  float peak=0;for(int i=0;i<256;++i){assert(std::isfinite(l[i])&&l[i]==r[i]);peak=std::max(peak,std::abs(l[i]));}assert(peak>0);
  synth.sustain(0,true);synth.noteOff(0,60);assert(synth.activeVoices()==1);
  synth.sustain(0,false);for(int n=0;n<100;++n)synth.process(l.data(),r.data(),l.size());assert(synth.activeVoices()==0);
  for(int n=0;n<20;++n)synth.noteOn(0,40+n,127);assert(synth.activeVoices()==16);
  synth.pitchBend(0,1.0f);synth.process(l.data(),r.data(),l.size());
  synth.allNotesOff(0);for(int n=0;n<100;++n)synth.process(l.data(),r.data(),l.size());assert(synth.activeVoices()==0);
  synth.noteOn(1,64,90);synth.panic();assert(synth.activeVoices()==0);
  synth.prepare(44100);assert(synth.sampleRate()==44100);
  // Exercise all six filters, LFOs, modulation destinations, hard sync and MIDI expression.
  for(int mode=0;mode<6;++mode){
    auto cfg=synth.parameters();
    cfg.filterMode=static_cast<liberty::FreedomDSP::FilterMode>(mode);
    cfg.resonance=.6f;cfg.cutoffHz=800;
    for(int j=0;j<3;++j){cfg.lfos[j].rateHz=1.5f+j;cfg.lfos[j].depth=.7f;cfg.lfos[j].wave=static_cast<liberty::FreedomDSP::LFOWave>(j);}
    cfg.matrix[0]={1,1,.6f};cfg.matrix[1]={2,2,.5f};cfg.matrix[2]={3,3,-.5f};
    cfg.matrix[3]={4,1,.3f};cfg.matrix[4]={5,2,.2f};cfg.matrix[5]={6,3,.1f};
    cfg.syncOsc2=true;cfg.syncOsc3=true;
    cfg.osc[1].enabled=true;cfg.osc[2].enabled=true;
    synth.setParameters(cfg);
    synth.modWheel(0,.7f);synth.channelPressure(0,.6f);
    synth.noteOn(0,60,110);
    for(int block=0;block<40;++block){synth.process(l.data(),r.data(),l.size());for(float v:l)assert(std::isfinite(v));}
    synth.panic();
  }
  // Effects: bypass symmetry, stereo modulation, order switching and finite output.
  synth.prepare(48000);
  auto fx=synth.parameters();fx.osc[0].wave=liberty::FreedomDSP::Wave::Saw;
  fx.chorus.enabled=true;fx.chorus.mix=.7f;fx.chorus.rateHz=1.7f;fx.chorus.depthMs=6;
  fx.drive.enabled=true;fx.drive.amount=.8f;fx.drive.mix=.8f;fx.drive.tone=.5f;
  for(int order=0;order<2;++order){
    fx.driveBeforeChorus=order!=0;synth.setParameters(fx);synth.noteOn(0,52,127);
    bool stereoDifference=false;
    for(int block=0;block<150;++block){
      synth.process(l.data(),r.data(),l.size());
      for(int j=0;j<256;++j){assert(std::isfinite(l[j])&&std::isfinite(r[j]));
        assert(std::abs(l[j])<=1.0f&&std::abs(r[j])<=1.0f);
        if(std::abs(l[j]-r[j])>0.00001f)stereoDifference=true;
      }
    }
    assert(stereoDifference);synth.panic();
  }
  fx.chorus.enabled=false;fx.drive.enabled=false;synth.setParameters(fx);
  synth.noteOn(0,60,100);synth.process(l.data(),r.data(),l.size());
  for(int j=0;j<256;++j)assert(l[j]==r[j]);
  std::cout<<"PASS: audio finite, stereo, note on/off, sustain, 16 voices, pitch bend, all notes off, panic, sample rate\n";
}
