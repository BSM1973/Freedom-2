#include "FreedomDSP.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace liberty {
namespace {
constexpr double pi = 3.14159265358979323846;
float clamp(float x, float lo, float hi) noexcept { return std::max(lo, std::min(x, hi)); }
int channelIndex(int channel) noexcept { return std::max(0, std::min(channel,15)); }
}
FreedomDSP::FreedomDSP(double rate) noexcept { prepare(rate); }
void FreedomDSP::prepare(double rate) noexcept {
  sampleRate_ = (std::isfinite(rate) && rate >= 8000.0 && rate <= 384000.0) ? rate : 48000.0;
  panic();
  chorusLeft_.fill(0.0f); chorusRight_.fill(0.0f);
  chorusWrite_=0; chorusPhase_=0; driveToneLeft_=driveToneRight_=0;
}
void FreedomDSP::setParameters(const Parameters& p) noexcept {
  params_ = p;
  params_.attackSeconds = clamp(p.attackSeconds, 0.001f, 30.0f);
  params_.decaySeconds = clamp(p.decaySeconds, 0.001f, 30.0f);
  params_.sustain = clamp(p.sustain, 0.0f, 1.0f);
  params_.releaseSeconds = clamp(p.releaseSeconds, 0.001f, 30.0f);
  params_.cutoffHz = clamp(p.cutoffHz, 20.0f, static_cast<float>(sampleRate_*0.45));
  params_.masterGain = clamp(p.masterGain, 0.0f, 1.0f);
  params_.resonance = clamp(p.resonance,0.0f,1.0f);
  params_.chorus.rateHz=clamp(p.chorus.rateHz,0.05f,12.0f);
  params_.chorus.depthMs=clamp(p.chorus.depthMs,0.0f,12.0f);
  params_.chorus.mix=clamp(p.chorus.mix,0.0f,1.0f);
  params_.drive.amount=clamp(p.drive.amount,0.0f,1.0f);
  params_.drive.tone=clamp(p.drive.tone,0.0f,1.0f);
  params_.drive.mix=clamp(p.drive.mix,0.0f,1.0f);
  for(auto& l:params_.lfos){l.rateHz=clamp(l.rateHz,0.01f,40.0f);l.depth=clamp(l.depth,0.0f,1.0f);}
  for(auto& r:params_.matrix){r.source=std::max(0,std::min(r.source,6));r.destination=std::max(0,std::min(r.destination,3));r.amount=clamp(r.amount,-1.0f,1.0f);}
  params_.bendRangeSemitones = clamp(p.bendRangeSemitones, 0.0f, 48.0f);
  for (auto& o : params_.osc) {
    o.level = clamp(o.level, 0.0f, 1.0f);
    o.octave = std::max(-4,std::min(o.octave,4));
    o.semitone = std::max(-24,std::min(o.semitone,24));
    o.fineCents = clamp(o.fineCents,-100.0f,100.0f);
  }
}
void FreedomDSP::noteOn(int channel,int note,int velocity) noexcept {
  if (note<0 || note>127 || velocity<0 || velocity>127) return;
  if (velocity==0) { noteOff(channel,note); return; }
  channel=channelIndex(channel);
  Voice* target=nullptr;
  for (auto& v:voices_) if(v.stage==Stage::Off) {target=&v;break;}
  if(!target) for(auto& v:voices_) if(v.stage==Stage::Release && (!target || v.envelope<target->envelope)) target=&v;
  if(!target) target=&*std::min_element(voices_.begin(),voices_.end(),[](const Voice&a,const Voice&b){return a.age<b.age;});
  *target=Voice{};
  target->stage=Stage::Attack;target->channel=channel;target->note=note;
  target->velocity=velocity/127.0f;target->age=++age_;
}
void FreedomDSP::releaseVoice(Voice& v) noexcept {if(v.stage!=Stage::Off) {v.stage=Stage::Release;v.heldByPedal=false;}}
void FreedomDSP::noteOff(int channel,int note) noexcept {
  channel=channelIndex(channel);
  // Release only the most recent matching key, allowing repeated notes to overlap.
  Voice* found=nullptr;
  for(auto& v:voices_) if(v.stage!=Stage::Off && v.stage!=Stage::Release && v.channel==channel && v.note==note && (!found || v.age>found->age)) found=&v;
  if(found) {if(pedal_[channel]) found->heldByPedal=true;else releaseVoice(*found);}
}
void FreedomDSP::sustain(int channel,bool down) noexcept {
  channel=channelIndex(channel);pedal_[channel]=down;
  if(!down) for(auto& v:voices_) if(v.channel==channel && v.heldByPedal) releaseVoice(v);
}
void FreedomDSP::pitchBend(int channel,float normalized) noexcept {bend_[channelIndex(channel)]=clamp(normalized,-1.0f,1.0f);}
void FreedomDSP::modWheel(int channel,float value) noexcept {mod_[channelIndex(channel)]=clamp(value,0.0f,1.0f);}
void FreedomDSP::channelPressure(int channel,float value) noexcept {pressure_[channelIndex(channel)]=clamp(value,0.0f,1.0f);}
void FreedomDSP::allNotesOff(int channel) noexcept {channel=channelIndex(channel);pedal_[channel]=false;for(auto& v:voices_)if(v.channel==channel)releaseVoice(v);}
void FreedomDSP::panic() noexcept {for(auto& v:voices_)v=Voice{};pedal_.fill(false);bend_.fill(0.0f);mod_.fill(0.0f);pressure_.fill(0.0f);lfoPhase_.fill(0.0);}
int FreedomDSP::activeVoices() const noexcept {int count=0;for(const auto&v:voices_)if(v.stage!=Stage::Off)++count;return count;}
float FreedomDSP::waveform(Wave wave,double phase) noexcept {
  switch(wave) {
    case Wave::Saw:return static_cast<float>(2.0*phase-1.0);
    case Wave::Square:return phase<0.5?1.0f:-1.0f;
    case Wave::Triangle:return static_cast<float>(1.0-4.0*std::abs(phase-0.5));
    case Wave::Sine:return static_cast<float>(std::sin(2.0*pi*phase));
  }
  return 0.0f;
}
namespace {
struct Coeff {double b0,b1,b2,a1,a2;};
Coeff biquad(liberty::FreedomDSP::FilterMode mode,double hz,double q,double sr) noexcept {
  const double w=2*pi*std::max(20.0,std::min(hz,sr*.45))/sr;
  const double c=std::cos(w), sn=std::sin(w), alpha=sn/(2*std::max(.15,q));
  double b0=1,b1=0,b2=0;
  switch(mode){
    case liberty::FreedomDSP::FilterMode::LP24: case liberty::FreedomDSP::FilterMode::LP12:b0=(1-c)/2;b1=1-c;b2=b0;break;
    case liberty::FreedomDSP::FilterMode::HP24: case liberty::FreedomDSP::FilterMode::HP12:b0=(1+c)/2;b1=-(1+c);b2=b0;break;
    case liberty::FreedomDSP::FilterMode::BP12:b0=alpha;b1=0;b2=-alpha;break;
    case liberty::FreedomDSP::FilterMode::Notch:b0=1;b1=-2*c;b2=1;break;
  }
  const double a0=1+alpha;
  return {b0/a0,b1/a0,b2/a0,(-2*c)/a0,(1-alpha)/a0};
}
float lfoValue(liberty::FreedomDSP::LFOWave wave,double phase) noexcept {
  switch(wave){
    case liberty::FreedomDSP::LFOWave::Sine:return static_cast<float>(std::sin(2*pi*phase));
    case liberty::FreedomDSP::LFOWave::Triangle:return static_cast<float>(1-4*std::abs(phase-.5));
    case liberty::FreedomDSP::LFOWave::Saw:return static_cast<float>(2*phase-1);
    case liberty::FreedomDSP::LFOWave::Square:return phase<.5?1.f:-1.f;
    case liberty::FreedomDSP::LFOWave::ReverseSaw:return static_cast<float>(1-2*phase);
  }
  return 0;
}
}
void FreedomDSP::applyChorus(float& l,float& r) noexcept {
  const auto& c=params_.chorus;
  // Keep the delay history warm even when bypassed for seamless activation.
  chorusLeft_[chorusWrite_]=l;
  chorusRight_[chorusWrite_]=r;
  if(c.enabled && c.mix>0) {
    const double base=0.018*sampleRate_;
    const double depth=c.depthMs*0.001*sampleRate_;
    const auto tap=[&](const std::array<float,DelaySize>& buf,double delay) noexcept {
      double pos=static_cast<double>(chorusWrite_)-delay;
      if(pos<0)pos+=DelaySize;
      const auto a=static_cast<std::size_t>(pos)&(DelaySize-1);
      const auto b=(a+1)&(DelaySize-1);
      const float frac=static_cast<float>(pos-std::floor(pos));
      return buf[a]+(buf[b]-buf[a])*frac;
    };
    const float wetL=tap(chorusLeft_,base+depth*std::sin(2*pi*chorusPhase_));
    const float wetR=tap(chorusRight_,base+depth*std::sin(2*pi*(chorusPhase_+0.25)));
    l=l*(1-c.mix)+wetL*c.mix;
    r=r*(1-c.mix)+wetR*c.mix;
  }
  chorusWrite_=(chorusWrite_+1)&(DelaySize-1);
  chorusPhase_+=c.rateHz/sampleRate_;
  if(chorusPhase_>=1)chorusPhase_-=1;
}
void FreedomDSP::applyDrive(float& l,float& r) noexcept {
  const auto& d=params_.drive;
  if(!d.enabled || d.mix<=0)return;
  const float gain=1.0f+25.0f*d.amount*d.amount;
  const float norm=std::tanh(gain);
  const float alpha=clamp(0.02f+0.95f*d.tone,0.02f,0.97f);
  const auto saturate=[&](float input,float& toneMemory) noexcept {
    const float shaped=std::tanh(input*gain)/norm;
    toneMemory+=alpha*(shaped-toneMemory);
    return input*(1-d.mix)+toneMemory*d.mix;
  };
  l=saturate(l,driveToneLeft_);r=saturate(r,driveToneRight_);
}
void FreedomDSP::process(float* left,float* right,std::size_t frames) noexcept {
  if(!left||!right)return;
  // Coefficients and LFOs are refreshed in small control-rate chunks, without allocations.
  std::array<float,3> lfo{};
  for(std::size_t base=0;base<frames;base+=16) {
    const std::size_t count=std::min<std::size_t>(16,frames-base);
    for(int k=0;k<3;++k) {
      const auto& cfg=params_.lfos[k];
      lfo[k]=lfoValue(cfg.wave,lfoPhase_[k])*cfg.depth;
      lfoPhase_[k]+=static_cast<double>(count)*cfg.rateHz/sampleRate_;
      lfoPhase_[k]-=std::floor(lfoPhase_[k]);
    }
    for(std::size_t i=base;i<base+count;++i) {
      float mix=0.0f;
      for(auto&v:voices_) {
        if(v.stage==Stage::Off)continue;
        switch(v.stage) {
          case Stage::Attack:v.envelope+=static_cast<float>(1.0/(params_.attackSeconds*sampleRate_));if(v.envelope>=1){v.envelope=1;v.stage=Stage::Decay;}break;
          case Stage::Decay:v.envelope-=static_cast<float>((1-params_.sustain)/(params_.decaySeconds*sampleRate_));if(v.envelope<=params_.sustain){v.envelope=params_.sustain;v.stage=Stage::Sustain;}break;
          case Stage::Sustain:v.envelope=params_.sustain;break;
          case Stage::Release:v.envelope-=static_cast<float>(1.0/(params_.releaseSeconds*sampleRate_));if(v.envelope<=0){v=Voice{};continue;}break;
          case Stage::Off:break;
        }
        float cutoffMod=0,pitchMod=0,ampMod=0;
        for(const auto&r:params_.matrix) {
          if(!r.source||!r.destination||r.amount==0)continue;
          float source=0;
          if(r.source<=3)source=lfo[r.source-1];
          else if(r.source==4)source=mod_[v.channel];
          else if(r.source==5)source=pressure_[v.channel];
          else source=v.velocity;
          const float value=source*r.amount;
          if(r.destination==1)cutoffMod+=value;
          else if(r.destination==2)pitchMod+=value;
          else if(r.destination==3)ampMod+=value;
        }
        float sample=0;
        bool masterWrapped=false;
        for(int j=0;j<3;++j) {
          const auto&o=params_.osc[j];
          const double semis=static_cast<double>(v.note-69+12*o.octave+o.semitone)+o.fineCents/100.0+bend_[v.channel]*params_.bendRangeSemitones+pitchMod*2.0;
          const double freq=std::min(sampleRate_*.45,440.0*std::exp2(semis/12.0));
          const double advanced=v.phase[j]+freq/sampleRate_;
          const bool wrapped=advanced>=1.0;
          v.phase[j]=advanced-std::floor(advanced);
          if(j==0)masterWrapped=wrapped;
          if(j==1 && params_.syncOsc2 && masterWrapped)v.phase[j]=0;
          if(j==2 && params_.syncOsc3 && masterWrapped)v.phase[j]=0;
          if(o.enabled && o.level>0)sample+=waveform(o.wave,v.phase[j])*o.level;
        }
        // Per-voice biquad history; coefficient updates are block-local and bounded.
        const double cutoff=std::max(20.0,std::min(sampleRate_*.45,static_cast<double>(params_.cutoffHz)*std::exp2(cutoffMod*4.0)));
        const double q=.707+params_.resonance*11.0;
        const Coeff c=biquad(params_.filterMode,cutoff,q,sampleRate_);
        const int stages=(params_.filterMode==FilterMode::LP24||params_.filterMode==FilterMode::HP24)?2:1;
        double filtered=sample;
        for(int k=0;k<stages;++k){
          auto& f=v.filter[k];
          const double y=c.b0*filtered+c.b1*f.x1+c.b2*f.x2-c.a1*f.y1-c.a2*f.y2;
          f.x2=f.x1;f.x1=filtered;f.y2=f.y1;f.y1=y;
          filtered=std::isfinite(y)?y:0.0;
        }
        mix+=static_cast<float>(filtered)*v.envelope*v.velocity*clamp(1+ampMod*.75f,0,2);
      }
      const float out=std::tanh(mix*params_.masterGain);
      float l=out,r=out;
      if(params_.driveBeforeChorus){applyDrive(l,r);applyChorus(l,r);}
      else {applyChorus(l,r);applyDrive(l,r);}
      left[i]=std::tanh(l);right[i]=std::tanh(r);
    }
  }
}
}
