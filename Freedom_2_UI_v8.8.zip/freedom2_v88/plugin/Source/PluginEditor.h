#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <memory>
#include <vector>

class Freedom2Editor final : public juce::AudioProcessorEditor,
                             private juce::Button::Listener {
public:
 explicit Freedom2Editor(Freedom2Processor&);
 ~Freedom2Editor() override;
 void paint(juce::Graphics&) override;
 void resized() override;
private:
 struct Dial {
  juce::Slider slider;
  juce::Label caption;
  std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
 };
 struct Selector {
  juce::ComboBox combo;
  juce::Label caption;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> attachment;
 };
 struct TitaniumLookAndFeel : juce::LookAndFeel_V4 {
  void drawRotarySlider(juce::Graphics&, int, int, int, int, float, float, float, juce::Slider&) override;
  void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&, bool, bool) override;
 };
 struct Toggle {
  juce::ToggleButton button;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> attachment;
 };
 void buttonClicked(juce::Button*) override;
 void addDial(int page, const juce::String& param, const juce::String& label);
 void addSelector(int page, const juce::String& param, const juce::String& label);
 void addToggle(int page, const juce::String& param, const juce::String& label);
 void updatePage();
 void savePreset();
 void loadPreset();
 struct FactoryPreset { juce::String name, category; int index; };
 void initFactoryPresets();
 void refreshPresetList();
 void applyFactoryPreset(int index);
 void selectRelativePreset(int direction);
 void toggleFavourite();
 void saveFavourites() const;
 void loadFavourites();
 void setBrowserVisible(bool visible);
 juce::TextButton browserButton{"PRESET BROWSER"}, favouriteButton{"☆ FAVORITE"};
 juce::TextButton previousPreset{"◀ PREV"}, nextPreset{"NEXT ▶"};
 juce::ComboBox categoryFilter;
 juce::TextEditor searchBox;
 juce::ListBox presetList;
 std::vector<FactoryPreset> factoryPresets;
 juce::StringArray favourites;
 juce::String currentFactoryName;
 int currentFactoryIndex=-1;
 bool browserVisible=false;
 struct PresetListModel final : juce::ListBoxModel {
  Freedom2Editor& owner;
  explicit PresetListModel(Freedom2Editor& e):owner(e){}
  int getNumRows() override;
  void paintListBoxItem(int,juce::Graphics&,int,int,bool) override;
  void selectedRowsChanged(int) override;
 } presetModel{*this};
 std::vector<int> filteredPresets;
 Freedom2Processor& processor;
 TitaniumLookAndFeel titanium;
 juce::TextButton saveButton{"SAVE PRESET"}, loadButton{"LOAD PRESET"};
 juce::Label presetStatus;
 juce::Label title, subtitle, sectionTitle;
 std::array<juce::TextButton,4> tabs;
 std::array<juce::String,4> tabNames{{"ENGINE","MODULATIONS","EFFECTS","PERFORMANCE"}};
 std::vector<std::unique_ptr<Dial>> dials;
 std::vector<std::unique_ptr<Toggle>> toggles;
 std::vector<std::unique_ptr<Selector>> selectors;
 std::vector<int> selectorPages;
 std::vector<int> dialPages, togglePages;
 juce::MidiKeyboardComponent keyboard;
 int activePage=0;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Freedom2Editor)
};
