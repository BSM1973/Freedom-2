#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>
using APF=juce::AudioParameterFloat;
using APC=juce::AudioParameterChoice;
using APB=juce::AudioParameterBool;
using P=juce::AudioProcessorParameter;
Freedom2Processor::Freedom2Processor():juce::AudioProcessor(BusesProperties().withOutput("Output",juce::AudioChannelSet::stereo(),true)),apvts(*this,nullptr,"PARAMETERS",makeLayout()){}
juce::AudioProcessorValueTreeState::ParameterLayout Freedom2Processor::makeLayout(){
  juce::AudioProcessorValueTreeState::ParameterLayout layout;
  auto f=[&](const char* id,const char* name,float lo,float hi,float def){layout.add(std::make_unique<APF>(juce::ParameterID{id,1},name,juce::NormalisableRange<float>(lo,hi),def));};
  auto b=[&](const char* id,const char* name,bool def){layout.add(std::make_unique<APB>(juce::ParameterID{id,1},name,def));};
  auto c=[&](const char* id,const char* name,juce::StringArray options,int def){layout.add(std::make_unique<APC>(juce::ParameterID{id,1},name,options,def));};
  f("master","Master",0,1,.25f);f("attack","Attack",.001f,8,.01f);f("decay","Decay",.001f,8,.15f);f("sustain","Sustain",0,1,.7f);f("release","Release",.001f,12,.25f);
  f("cutoff","Cutoff",20,20000,12000);f("resonance","Resonance",0,1,.2f);c("filterMode","Filter Mode",{"LP24","LP12","HP24","HP12","BP12","NOTCH"},1);f("bendRange","Bend Range",0,24,2);
  for(int i=1;i<=3;++i){auto n=juce::String(i);auto id=[&](const char* k){return ("osc"+n+k).toStdString();};
    auto addFloat=[&](const char* k,float lo,float hi,float def){auto key=id(k);layout.add(std::make_unique<APF>(juce::ParameterID{key,1},"OSC "+n+" "+k,juce::NormalisableRange<float>(lo,hi),def));};
    auto enabled=id("On");layout.add(std::make_unique<APB>(juce::ParameterID{enabled,1},"OSC "+n+" On",true));
    auto wave=id("Wave");layout.add(std::make_unique<APC>(juce::ParameterID{wave,1},"OSC "+n+" Wave",juce::StringArray{"Saw","Square","Triangle","Sine"},0));
    addFloat("Level",0,1,.3f);addFloat("Octave",-3,3,0);addFloat("Semitone",-12,12,0);addFloat("Fine",-100,100,0);
  }
  b("sync2","OSC2 Hard Sync",false);b("sync3","OSC3 Hard Sync",false);
  for(int i=1;i<=3;++i){auto n=juce::String(i);auto id=[&](const char* k){return ("lfo"+n+k).toStdString();};
    auto rate=id("Rate");layout.add(std::make_unique<APF>(juce::ParameterID{rate,1},"LFO "+n+" Rate",juce::NormalisableRange<float>(.01f,30.f),1.f));
    auto depth=id("Depth");layout.add(std::make_unique<APF>(juce::ParameterID{depth,1},"LFO "+n+" Depth",juce::NormalisableRange<float>(0.f,1.f),0.f));
    auto wave=id("Wave");layout.add(std::make_unique<APC>(juce::ParameterID{wave,1},"LFO "+n+" Wave",juce::StringArray{"Sine","Triangle","Saw","Square","Reverse Saw"},0));
  }
  for(int i=1;i<=8;++i){auto n=juce::String(i);auto base="route"+n;
    layout.add(std::make_unique<APC>(juce::ParameterID{(base+"Source").toStdString(),1},base+" Source",juce::StringArray{"Off","LFO1","LFO2","LFO3","Mod Wheel","Pressure","Velocity"},0));
    layout.add(std::make_unique<APC>(juce::ParameterID{(base+"Dest").toStdString(),1},base+" Destination",juce::StringArray{"Off","Cutoff","Pitch","Amplitude"},0));
    layout.add(std::make_unique<APF>(juce::ParameterID{(base+"Amount").toStdString(),1},base+" Amount",juce::NormalisableRange<float>(-1.f,1.f),0.f));
  }
  b("chorusOn","Chorus On",false);f("chorusRate","Chorus Rate",.05f,10,.8f);f("chorusDepth","Chorus Depth",0,15,3.5f);f("chorusMix","Chorus Mix",0,1,.25f);
  b("driveOn","Drive On",false);f("driveAmount","Drive Amount",0,1,.35f);f("driveTone","Drive Tone",0,1,.65f);f("driveMix","Drive Mix",0,1,.35f);b("driveFirst","Drive Before Chorus",false);
  return layout;
}
void Freedom2Processor::prepareToPlay(double sr,int block){dsp.prepare(sr);scratchL.resize((size_t)std::max(1,block));scratchR.resize((size_t)std::max(1,block));dsp.panic();}
bool Freedom2Processor::isBusesLayoutSupported(const BusesLayout& l)const{return l.getMainOutputChannelSet()==juce::AudioChannelSet::stereo() && l.getMainInputChannelSet().isDisabled();}
void Freedom2Processor::syncParameters(){
  auto val=[&](const juce::String& id){auto* p=apvts.getRawParameterValue(id);return p?p->load():0.f;};
  liberty::FreedomDSP::Parameters p{};
  p.masterGain=val("master");p.attackSeconds=val("attack");p.decaySeconds=val("decay");p.sustain=val("sustain");p.releaseSeconds=val("release");p.cutoffHz=val("cutoff");p.resonance=val("resonance");p.bendRangeSemitones=val("bendRange");p.filterMode=static_cast<liberty::FreedomDSP::FilterMode>((int)val("filterMode"));
  for(int i=0;i<3;++i){auto pre="osc"+juce::String(i+1);auto& o=p.osc[(size_t)i];o.enabled=val(pre+"On")>.5f;o.wave=static_cast<liberty::FreedomDSP::Wave>((int)val(pre+"Wave"));o.level=val(pre+"Level");o.octave=(int)val(pre+"Octave");o.semitone=(int)val(pre+"Semitone");o.fineCents=val(pre+"Fine");
    auto lfo="lfo"+juce::String(i+1);p.lfos[(size_t)i].rateHz=val(lfo+"Rate");p.lfos[(size_t)i].depth=val(lfo+"Depth");p.lfos[(size_t)i].wave=static_cast<liberty::FreedomDSP::LFOWave>((int)val(lfo+"Wave"));
  }
  p.syncOsc2=val("sync2")>.5f;p.syncOsc3=val("sync3")>.5f;
  for(int i=0;i<8;++i){auto pre="route"+juce::String(i+1);auto& r=p.matrix[(size_t)i];r.source=(int)val(pre+"Source");r.destination=(int)val(pre+"Dest");r.amount=val(pre+"Amount");}
  p.chorus.enabled=val("chorusOn")>.5f;p.chorus.rateHz=val("chorusRate");p.chorus.depthMs=val("chorusDepth");p.chorus.mix=val("chorusMix");
  p.drive.enabled=val("driveOn")>.5f;p.drive.amount=val("driveAmount");p.drive.tone=val("driveTone");p.drive.mix=val("driveMix");p.driveBeforeChorus=val("driveFirst")>.5f;
  dsp.setParameters(p);
}
void Freedom2Processor::handleMidi(const juce::MidiMessage& m){int ch=m.getChannel()-1;
  if(m.isNoteOn())dsp.noteOn(ch,m.getNoteNumber(),juce::roundToInt(m.getVelocity()*127.f));
  else if(m.isNoteOff())dsp.noteOff(ch,m.getNoteNumber());
  else if(m.isPitchWheel())dsp.pitchBend(ch,juce::jlimit(-1.f,1.f,(m.getPitchWheelValue()-8192.f)/8192.f));
  else if(m.isChannelPressure())dsp.channelPressure(ch,m.getChannelPressureValue()/127.f);
  else if(m.isController()){int cc=m.getControllerNumber();float v=m.getControllerValue()/127.f;
    if(cc==1)dsp.modWheel(ch,v);else if(cc==64)dsp.sustain(ch,v>=.5f);else if(cc==120)dsp.panic();else if(cc==123)dsp.allNotesOff(ch);
  }
}
void Freedom2Processor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer& midi){
  juce::ScopedNoDenormals noDenormals;
  keyboardState.processNextMidiBuffer(midi, 0, buffer.getNumSamples(), true);
  buffer.clear();syncParameters();
  const int total=buffer.getNumSamples();if(total<=0)return;
  int pos=0;
  auto render=[&](int frames){while(frames>0){int n=std::min(frames,(int)scratchL.size());if(n<=0)return;dsp.process(scratchL.data(),scratchR.data(),(size_t)n);buffer.copyFrom(0,pos,scratchL.data(),n);buffer.copyFrom(1,pos,scratchR.data(),n);pos+=n;frames-=n;}};
  for(const auto meta:midi){int sample=juce::jlimit(0,total,meta.samplePosition);if(sample<pos)sample=pos;render(sample-pos);handleMidi(meta.getMessage());}
  render(total-pos);midi.clear();
}
void Freedom2Processor::getStateInformation(juce::MemoryBlock& out){auto xml=apvts.copyState().createXml();copyXmlToBinary(*xml,out);}
void Freedom2Processor::setStateInformation(const void* data,int size){auto xml=getXmlFromBinary(data,size);if(xml && xml->hasTagName(apvts.state.getType()))apvts.replaceState(juce::ValueTree::fromXml(*xml));}
juce::AudioProcessorEditor* Freedom2Processor::createEditor(){return new Freedom2Editor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new Freedom2Processor();}
