#include "PluginEditor.h"
#include <algorithm>

namespace {
const juce::Colour bg(0xff10151d), panel(0xff1c2530), stroke(0xff3d5266);
const juce::Colour ink(0xffe9eef5), muted(0xff90a7bd), accent(0xff55c6de);
}

Freedom2Editor::Freedom2Editor(Freedom2Processor& p)
 : juce::AudioProcessorEditor(&p), processor(p),
   keyboard(p.keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard) {
 setLookAndFeel(&titanium);
 setSize(1150, 750);
 setResizable(true, true);
 setResizeLimits(950, 660, 1600, 1000);
 saveButton.onClick=[this]{savePreset();}; loadButton.onClick=[this]{loadPreset();};
 addAndMakeVisible(saveButton); addAndMakeVisible(loadButton);
 browserButton.onClick=[this]{setBrowserVisible(!browserVisible);};
 previousPreset.onClick=[this]{selectRelativePreset(-1);};
 nextPreset.onClick=[this]{selectRelativePreset(1);};
 favouriteButton.onClick=[this]{toggleFavourite();};
 for(auto* b:{&browserButton,&previousPreset,&nextPreset,&favouriteButton})addAndMakeVisible(*b);
 categoryFilter.addItem("ALL CATEGORIES",1);
 for(const auto& cat:{"BASS","LEAD","PAD","KEYS","PLUCK","FX"})categoryFilter.addItem(cat,categoryFilter.getNumItems()+1);
 categoryFilter.setSelectedId(1,juce::dontSendNotification);
 categoryFilter.onChange=[this]{refreshPresetList();};addAndMakeVisible(categoryFilter);
 searchBox.setTextToShowWhenEmpty("Search 100 factory presets...",muted);
 searchBox.onTextChange=[this]{refreshPresetList();};addAndMakeVisible(searchBox);
 presetList.setModel(&presetModel);presetList.setRowHeight(29);
 presetList.setColour(juce::ListBox::backgroundColourId,juce::Colour(0xff17222d));
 addAndMakeVisible(presetList);
 initFactoryPresets();loadFavourites();refreshPresetList();
 presetStatus.setText("PRESET: INIT",juce::dontSendNotification);
 presetStatus.setColour(juce::Label::textColourId,muted); addAndMakeVisible(presetStatus);
 title.setText("FREEDOM 2", juce::dontSendNotification);
 title.setFont(juce::FontOptions(31.f, juce::Font::bold));
 title.setColour(juce::Label::textColourId, ink); addAndMakeVisible(title);
 subtitle.setText("LIBERTY  /  GRAPHITE TITANIUM  /  NATIVE v8.8", juce::dontSendNotification);
 subtitle.setColour(juce::Label::textColourId, muted);addAndMakeVisible(subtitle);
 sectionTitle.setColour(juce::Label::textColourId, accent);
 sectionTitle.setFont(juce::FontOptions(17.f, juce::Font::bold)); addAndMakeVisible(sectionTitle);
 for (int i=0;i<4;++i) {
  tabs[(size_t)i].setButtonText(tabNames[(size_t)i]);
  tabs[(size_t)i].addListener(this);
  addAndMakeVisible(tabs[(size_t)i]);
 }
 // ENGINE
 for (const auto& entry : std::initializer_list<std::pair<const char*,const char*>>{
  {"master","MASTER"},{"cutoff","CUTOFF"},{"resonance","RESONANCE"},
  {"attack","ATTACK"},{"decay","DECAY"},{"sustain","SUSTAIN"},{"release","RELEASE"},
  {"osc1Level","OSC 1 LEVEL"},{"osc2Level","OSC 2 LEVEL"},{"osc3Level","OSC 3 LEVEL"},
  {"osc1Fine","OSC 1 FINE"},{"osc2Fine","OSC 2 FINE"},{"osc3Fine","OSC 3 FINE"},
  {"bendRange","BEND RANGE"}}) addDial(0,entry.first,entry.second);
 addToggle(0,"osc1On","OSC 1 ON");addToggle(0,"osc2On","OSC 2 ON");addToggle(0,"osc3On","OSC 3 ON");
 addToggle(0,"sync2","OSC 2 HARD SYNC");addToggle(0,"sync3","OSC 3 HARD SYNC");
 for(int i=1;i<=3;++i) addSelector(0,"osc"+juce::String(i)+"Wave","OSC "+juce::String(i)+" WAVE");
 addSelector(0,"filterMode","FILTER TYPE");
 // MODULATIONS
 for(int i=1;i<=3;++i) {
  auto n=juce::String(i);
  addDial(1,"lfo"+n+"Rate","LFO "+n+" RATE");
  addDial(1,"lfo"+n+"Depth","LFO "+n+" DEPTH");
  addSelector(1,"lfo"+n+"Wave","LFO "+n+" SHAPE");
 }
 for(int i=1;i<=8;++i) {
  auto r="route"+juce::String(i);
  addDial(1,r+"Amount","ROUTE "+juce::String(i)+" AMOUNT");
  addSelector(1,r+"Source","ROUTE "+juce::String(i)+" SOURCE");
  addSelector(1,r+"Dest","ROUTE "+juce::String(i)+" DEST");
 }
 // EFFECTS rack lives ONLY in page 2.
 addToggle(2,"chorusOn","CHORUS ON");addToggle(2,"driveOn","DRIVE ON");
 addToggle(2,"driveFirst","DRIVE BEFORE CHORUS");
 for(const auto& entry : std::initializer_list<std::pair<const char*,const char*>>{
  {"chorusRate","CHORUS RATE"},{"chorusDepth","CHORUS DEPTH"},{"chorusMix","CHORUS MIX"},
  {"driveAmount","DRIVE AMOUNT"},{"driveTone","DRIVE TONE"},{"driveMix","DRIVE MIX"}})
  addDial(2,entry.first,entry.second);
 // PERFORMANCE: parameters and MIDI keyboard available on every page.
 addDial(3,"master","OUTPUT LEVEL");addDial(3,"bendRange","PITCH BEND RANGE");
 keyboard.setAvailableRange(24,108);
 keyboard.setKeyWidth(19.f);
 keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId,accent.withAlpha(.6f));
 addAndMakeVisible(keyboard);
 updatePage();
 setBrowserVisible(false);
}
Freedom2Editor::~Freedom2Editor(){for(auto& t:tabs)t.removeListener(this);setLookAndFeel(nullptr);}
void Freedom2Editor::addDial(int page,const juce::String& id,const juce::String& label){
 auto d=std::make_unique<Dial>();
 d->slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
 d->slider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,94,18);
 d->slider.setColour(juce::Slider::rotarySliderFillColourId,accent);
 d->slider.setColour(juce::Slider::rotarySliderOutlineColourId,stroke);
 d->slider.setColour(juce::Slider::textBoxTextColourId,ink);
 d->slider.setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
 d->caption.setText(label,juce::dontSendNotification);
 d->caption.setJustificationType(juce::Justification::centred);
 d->caption.setColour(juce::Label::textColourId,muted);
 d->caption.setFont(juce::FontOptions(11.f,juce::Font::bold));
 addAndMakeVisible(d->slider);addAndMakeVisible(d->caption);
 d->attachment=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.apvts,id,d->slider);
 dialPages.push_back(page);dials.push_back(std::move(d));
}
void Freedom2Editor::addSelector(int page,const juce::String& id,const juce::String& label){
 auto s=std::make_unique<Selector>();
 if(auto* p=dynamic_cast<juce::AudioParameterChoice*>(processor.apvts.getParameter(id))){
  for(int i=0;i<p->choices.size();++i)s->combo.addItem(p->choices[i],i+1);
 }
 s->combo.setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff263443));
 s->combo.setColour(juce::ComboBox::textColourId,ink);
 s->combo.setColour(juce::ComboBox::outlineColourId,stroke);
 s->caption.setText(label,juce::dontSendNotification);
 s->caption.setJustificationType(juce::Justification::centredLeft);
 s->caption.setColour(juce::Label::textColourId,muted);
 s->caption.setFont(juce::FontOptions(10.f,juce::Font::bold));
 addAndMakeVisible(s->combo);addAndMakeVisible(s->caption);
 s->attachment=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(processor.apvts,id,s->combo);
 selectorPages.push_back(page);selectors.push_back(std::move(s));
}
void Freedom2Editor::savePreset(){
 auto chooser=std::make_shared<juce::FileChooser>("Save Freedom 2 preset",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),"*.freedom2");
 juce::Component::SafePointer<Freedom2Editor> safe(this);
 chooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting,
 [safe,chooser](const juce::FileChooser& fc){
  if(!safe)return;
  auto file=fc.getResult();if(file==juce::File{})return;
  file=file.withFileExtension("freedom2");
  if(auto xml=safe->processor.apvts.copyState().createXml()){
   if(xml->writeTo(file))safe->presetStatus.setText("SAVED: "+file.getFileNameWithoutExtension(),juce::dontSendNotification);
  }
 });
}
void Freedom2Editor::loadPreset(){
 auto chooser=std::make_shared<juce::FileChooser>("Load Freedom 2 preset",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),"*.freedom2");
 juce::Component::SafePointer<Freedom2Editor> safe(this);
 chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
 [safe,chooser](const juce::FileChooser& fc){
  if(!safe)return;
  auto file=fc.getResult();if(!file.existsAsFile())return;
  if(auto xml=juce::XmlDocument::parse(file)){
   if(xml->hasTagName(safe->processor.apvts.state.getType())){
    safe->processor.apvts.replaceState(juce::ValueTree::fromXml(*xml));
    safe->presetStatus.setText("LOADED: "+file.getFileNameWithoutExtension(),juce::dontSendNotification);
   }
  }
 });
}
void Freedom2Editor::TitaniumLookAndFeel::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&){
 auto r=juce::Rectangle<float>((float)x,(float)y,(float)w,(float)h).reduced(11.f);
 auto size=juce::jmin(r.getWidth(),r.getHeight());auto cx=r.getCentreX(),cy=r.getCentreY();
 auto rad=size*.39f; auto ring=juce::Rectangle<float>(cx-rad,cy-rad,rad*2,rad*2);
 juce::ColourGradient metal(juce::Colour(0xff657889),cx-rad,cy-rad,juce::Colour(0xff17212c),cx+rad,cy+rad,false);
 metal.addColour(.45,juce::Colour(0xff364653));
 g.setGradientFill(metal);g.fillEllipse(ring);
 g.setColour(juce::Colour(0xff0b1017));g.drawEllipse(ring,2.f);
 auto angle=start+pos*(end-start);
 juce::Path track;track.addCentredArc(cx,cy,rad+5,rad+5,0.f,start,end,true);
 g.setColour(juce::Colour(0xff3c4e5d));g.strokePath(track,juce::PathStrokeType(3.5f));
 juce::Path active;active.addCentredArc(cx,cy,rad+5,rad+5,0.f,start,angle,true);
 g.setColour(juce::Colour(0xff5dd3e5));g.strokePath(active,juce::PathStrokeType(3.5f));
 juce::Path needle;needle.addLineSegment(juce::Line<float>(cx+std::sin(angle)*rad*.34f,cy-std::cos(angle)*rad*.34f,cx+std::sin(angle)*rad*.78f,cy-std::cos(angle)*rad*.78f),2.8f);
 g.setColour(juce::Colour(0xfff1f8fc));g.fillPath(needle);
}
void Freedom2Editor::TitaniumLookAndFeel::drawButtonBackground(juce::Graphics& g,juce::Button& b,const juce::Colour& colour,bool hover,bool down){
 auto r=b.getLocalBounds().toFloat().reduced(1.f);
 g.setColour(down?colour.darker(.35f):hover?colour.brighter(.15f):colour);
 g.fillRoundedRectangle(r,7.f);g.setColour(juce::Colour(0xff506678));g.drawRoundedRectangle(r,7.f,1.f);
}
void Freedom2Editor::addToggle(int page,const juce::String& id,const juce::String& label){
 auto t=std::make_unique<Toggle>();t->button.setButtonText(label);
 t->button.setColour(juce::ToggleButton::textColourId,ink);
 t->button.setColour(juce::ToggleButton::tickColourId,accent);
 addAndMakeVisible(t->button);
 t->attachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(processor.apvts,id,t->button);
 togglePages.push_back(page);toggles.push_back(std::move(t));
}
void Freedom2Editor::buttonClicked(juce::Button* b){
 for(int i=0;i<4;++i)if(b==&tabs[(size_t)i]){activePage=i;updatePage();return;}
}
void Freedom2Editor::updatePage(){
 sectionTitle.setText(tabNames[(size_t)activePage]+"  /  LIBERTY",juce::dontSendNotification);
 for(size_t i=0;i<dials.size();++i){bool v=!browserVisible && dialPages[i]==activePage;dials[i]->slider.setVisible(v);dials[i]->caption.setVisible(v);}
 for(size_t i=0;i<toggles.size();++i)toggles[i]->button.setVisible(!browserVisible && togglePages[i]==activePage);
 for(size_t i=0;i<selectors.size();++i){bool v=!browserVisible && selectorPages[i]==activePage;selectors[i]->combo.setVisible(v);selectors[i]->caption.setVisible(v);}
 for(int i=0;i<4;++i){tabs[(size_t)i].setColour(juce::TextButton::buttonColourId,i==activePage?accent:panel);
 tabs[(size_t)i].setColour(juce::TextButton::textColourOffId,i==activePage?bg:ink);}
 resized();repaint();
}
void Freedom2Editor::paint(juce::Graphics& g){
 g.fillAll(bg);
 g.setColour(panel);g.fillRoundedRectangle(getLocalBounds().reduced(14).toFloat(),14.f);
 g.setColour(stroke);g.drawRoundedRectangle(getLocalBounds().reduced(14).toFloat(),14.f,1.3f);
 auto area=getLocalBounds().reduced(28);
 g.setColour(stroke);g.drawHorizontalLine(116,(float)area.getX(),(float)area.getRight());
 const int keyTop=getHeight()-157;
 g.setColour(juce::Colour(0xff131c26));g.fillRoundedRectangle((float)area.getX(),(float)keyTop,(float)area.getWidth(),122.f,9.f);
 g.setColour(accent);g.setFont(12.f);
 g.drawText("LIBERTY  •  MIDI KEYBOARD  •  AVAILABLE IN ALL TABS",area.getX()+12,keyTop+4,area.getWidth()-24,20,juce::Justification::left);
 if(!browserVisible && activePage==2){g.setColour(accent);g.setFont(12.f);g.drawText("EFFECTS RACK  /  CHORUS + DRIVE",area.getX()+14,170,400,20,juce::Justification::left);}
}
void Freedom2Editor::resized(){
 auto area=getLocalBounds().reduced(28);
 title.setBounds(area.getX()+12,area.getY()+5,350,42);
 subtitle.setBounds(area.getX()+14,area.getY()+46,620,24);
 saveButton.setBounds(area.getRight()-252,area.getY()+8,112,28);
 loadButton.setBounds(area.getRight()-130,area.getY()+8,112,28);
 presetStatus.setBounds(area.getRight()-380,area.getY()+44,365,23);
 browserButton.setBounds(area.getX()+340,area.getY()+8,152,29);
 previousPreset.setBounds(area.getX()+500,area.getY()+8,98,29);
 nextPreset.setBounds(area.getX()+602,area.getY()+8,98,29);
 const int browserY=area.getY()+167;
 categoryFilter.setBounds(area.getX()+20,browserY,190,30);
 searchBox.setBounds(area.getX()+220,browserY,330,30);
 favouriteButton.setBounds(area.getRight()-172,browserY,156,30);
 presetList.setBounds(area.getX()+20,browserY+42,area.getWidth()-40,std::max(90,getHeight()-157-browserY-57));
 auto tabArea=juce::Rectangle<int>(area.getX()+10,area.getY()+79,area.getWidth()-20,34);
 const int tabWidth=tabArea.getWidth()/4;
 for(int i=0;i<4;++i)tabs[(size_t)i].setBounds(tabArea.getX()+i*tabWidth,tabArea.getY(),tabWidth-7,32);
 sectionTitle.setBounds(area.getX()+14,area.getY()+130,area.getWidth()-28,24);
 const int keyTop=getHeight()-157;
 keyboard.setBounds(area.getX()+12,keyTop+27,area.getWidth()-24,88);
 int x=area.getX()+18,y=area.getY()+169;
 int contentWidth=area.getWidth()-36;
 int dialWidth=activePage==3?contentWidth:(activePage==1?contentWidth-370:contentWidth-184);
 int columns=std::max(3,std::min(6,dialWidth/122));
 int cellWidth=dialWidth/columns;
 int dialHeight=std::min(128,std::max(95,(keyTop-y-28)/3));
 int n=0;
 for(size_t i=0;i<dials.size();++i)if(dialPages[i]==activePage){
  int cx=x+(n%columns)*cellWidth,cy=y+(n/columns)*(dialHeight+25);
  dials[i]->slider.setBounds(cx,cy,cellWidth-6,dialHeight);
  dials[i]->caption.setBounds(cx,cy+dialHeight-2,cellWidth-6,19);++n;
 }
 int toggleX=x+dialWidth+10;
 int toggleY=y+5;
 int k=0;
 for(size_t i=0;i<toggles.size();++i)if(togglePages[i]==activePage){
  toggles[i]->button.setBounds(toggleX,toggleY+(k++)*26,170,25);
 }
 int sx=x+dialWidth+10, sy=y+((activePage==0)?150:0);
 int sw=175;
 int row=0;
 for(size_t i=0;i<selectors.size();++i)if(selectorPages[i]==activePage){
  auto& selector=*selectors[i];
  int px=sx+(activePage==1?(row%2)*180:0),py=sy+(activePage==1?(row/2)*49:row*49);
  selector.caption.setBounds(px,py,sw-8,16);
  selector.combo.setBounds(px,py+17,sw-12,27);
  ++row;
 }
}


// Factory presets are reproducible parameter recipes, not pre-recorded samples.
void Freedom2Editor::initFactoryPresets(){
 const std::array<std::pair<const char*,int>,6> categories{{{"BASS",20},{"LEAD",20},{"PAD",20},{"KEYS",15},{"PLUCK",15},{"FX",10}}};
 const std::array<juce::String,10> adjectives{{"Titanium","Velvet","Analog","Crystal","Midnight","Electric","Solar","Deep","Motion","Liberty"}};
 for(const auto& category:categories)
  for(int i=0;i<category.second;++i){
   const int number=i+1;
   auto name=juce::String(category.first)+" / "+adjectives[(size_t)(i%10)]+" "+juce::String(number).paddedLeft('0',2);
   factoryPresets.push_back({name,category.first,(int)factoryPresets.size()});
  }
}
int Freedom2Editor::PresetListModel::getNumRows(){return (int)owner.filteredPresets.size();}
void Freedom2Editor::PresetListModel::paintListBoxItem(int row,juce::Graphics& g,int w,int h,bool selected){
 if(row<0||row>=(int)owner.filteredPresets.size())return;
 const auto& p=owner.factoryPresets[(size_t)owner.filteredPresets[(size_t)row]];
 g.fillAll(selected?juce::Colour(0xff285265):(row%2?juce::Colour(0xff1b2936):juce::Colour(0xff17222d)));
 g.setColour(juce::Colour(0xff61cce0));g.setFont(juce::FontOptions(12.f,juce::Font::bold));
 g.drawText(p.category,10,0,65,h,juce::Justification::centredLeft);
 g.setColour(juce::Colour(0xffe9eef5));g.drawText(p.name,82,0,w-160,h,juce::Justification::centredLeft);
 if(owner.favourites.contains(p.name)){g.setColour(juce::Colour(0xffffd381));g.drawText("★",w-38,0,28,h,juce::Justification::centred);}
}
void Freedom2Editor::PresetListModel::selectedRowsChanged(int row){
 if(row>=0&&row<(int)owner.filteredPresets.size())owner.applyFactoryPreset(owner.filteredPresets[(size_t)row]);
}
void Freedom2Editor::refreshPresetList(){
 filteredPresets.clear();
 const auto category=categoryFilter.getSelectedId()<=1?juce::String():categoryFilter.getText();
 const auto term=searchBox.getText().trim();
 for(const auto& p:factoryPresets)
  if((category.isEmpty()||p.category==category)&&(term.isEmpty()||p.name.containsIgnoreCase(term)))filteredPresets.push_back(p.index);
 presetList.updateContent();presetList.repaint();
}
void Freedom2Editor::applyFactoryPreset(int index){
 if(index<0||index>=(int)factoryPresets.size())return;
 const auto& preset=factoryPresets[(size_t)index];
 // Deterministic, musically distinct starting points for 100 factory sounds.
 const int local=index-(preset.category=="BASS"?0:preset.category=="LEAD"?20:preset.category=="PAD"?40:preset.category=="KEYS"?60:preset.category=="PLUCK"?75:90);
 auto set=[this](const juce::String& id,float value){
  if(auto* p=processor.apvts.getParameter(id)){
   const float normalized=p->convertTo0to1(value);
   p->beginChangeGesture();p->setValueNotifyingHost(juce::jlimit(0.f,1.f,normalized));p->endChangeGesture();
  }
 };
 auto choice=[&](const juce::String& id,int value){set(id,(float)value);};
 set("master",.23f);
 set("osc1On",1.f);set("osc2On",1.f);set("osc3On",local%3==0?1.f:0.f);
 set("osc1Level",.36f);set("osc2Level",.20f+float(local%4)*.035f);set("osc3Level",.11f);
 choice("osc1Wave",local%4);choice("osc2Wave",(local+1)%4);choice("osc3Wave",(local+2)%4);
 set("osc1Octave",0.f);set("osc2Octave",0.f);set("osc3Octave",0.f);
 set("osc2Fine",float((local%7)-3)*2.f);
 set("sync2",local%5==0?1.f:0.f);set("sync3",0.f);
 set("resonance",.13f+float(local%5)*.08f);
 choice("filterMode",local%5==0?1:0);
 set("attack",.01f);set("decay",.2f);set("sustain",.7f);set("release",.3f);
 set("cutoff",6500.f);
 set("chorusOn",0.f);set("driveOn",0.f);
 for(int n=1;n<=3;++n){auto prefix="lfo"+juce::String(n);set(prefix+"Depth",0.f);set(prefix+"Rate",.5f+float(n));}
 for(int n=1;n<=8;++n){auto prefix="route"+juce::String(n);choice(prefix+"Source",0);choice(prefix+"Dest",0);set(prefix+"Amount",0.f);}
 if(preset.category=="BASS"){
  set("osc1Octave",-1.f);set("osc2Octave",-1.f);set("cutoff",300.f+float(local)*75.f);
  set("attack",.003f);set("decay",.12f+float(local%5)*.035f);set("sustain",.42f);set("release",.11f);
  set("driveOn",local%3==0?1.f:0.f);set("driveAmount",.25f);
 }else if(preset.category=="LEAD"){
  set("cutoff",1100.f+float(local)*430.f);set("attack",.005f);set("sustain",.85f);set("release",.19f);
  set("osc2Fine",float(local%11-5)*3.f);set("lfo1Rate",4.f+float(local%5));set("lfo1Depth",.17f);
  choice("route1Source",1);choice("route1Dest",2);set("route1Amount",.08f);
 }else if(preset.category=="PAD"){
  set("cutoff",1400.f+float(local)*260.f);set("attack",.6f+float(local%6)*.25f);
  set("release",1.5f+float(local%5)*.55f);set("sustain",.8f);
  set("chorusOn",1.f);set("chorusMix",.3f);set("lfo1Rate",.15f+float(local%4)*.08f);
  set("lfo1Depth",.5f);choice("route1Source",1);choice("route1Dest",1);set("route1Amount",.24f);
 }else if(preset.category=="KEYS"){
  set("cutoff",2000.f+float(local)*620.f);set("attack",.005f);set("decay",.3f+float(local%4)*.2f);
  set("sustain",.2f+float(local%3)*.12f);set("release",.3f);
 }else if(preset.category=="PLUCK"){
  set("cutoff",2600.f+float(local)*450.f);set("attack",.002f);set("decay",.07f+float(local%5)*.03f);
  set("sustain",.03f);set("release",.12f+float(local%4)*.07f);
 }else{
  set("cutoff",400.f+float(local)*1100.f);set("resonance",.6f);set("attack",.1f+float(local)*.13f);
  set("release",.6f);set("chorusOn",1.f);set("driveOn",local%2==0?1.f:0.f);
  set("lfo1Depth",.8f);set("lfo1Rate",1.f+float(local));
  choice("route1Source",1);choice("route1Dest",1);set("route1Amount",.7f);
 }
 currentFactoryIndex=index;currentFactoryName=preset.name;
 presetStatus.setText("FACTORY: "+preset.name,juce::dontSendNotification);
 favouriteButton.setButtonText(favourites.contains(preset.name)?"★ FAVORITE":"☆ FAVORITE");
}
void Freedom2Editor::selectRelativePreset(int direction){
 const int next=currentFactoryIndex<0?0:(currentFactoryIndex+direction+(int)factoryPresets.size())%(int)factoryPresets.size();
 applyFactoryPreset(next);
 if(browserVisible){for(int i=0;i<(int)filteredPresets.size();++i)if(filteredPresets[(size_t)i]==next){presetList.selectRow(i);break;}}
}
void Freedom2Editor::toggleFavourite(){
 if(currentFactoryIndex<0)return;
 if(favourites.contains(currentFactoryName))favourites.removeString(currentFactoryName);
 else favourites.addIfNotAlreadyThere(currentFactoryName);
 favouriteButton.setButtonText(favourites.contains(currentFactoryName)?"★ FAVORITE":"☆ FAVORITE");
 saveFavourites();presetList.repaint();
}
void Freedom2Editor::saveFavourites()const{
 auto file=juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
   .getChildFile("Liberty").getChildFile("Freedom2").getChildFile("favorites.txt");
 file.getParentDirectory().createDirectory();file.replaceWithText(favourites.joinIntoString("\n"));
}
void Freedom2Editor::loadFavourites(){
 auto file=juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
   .getChildFile("Liberty").getChildFile("Freedom2").getChildFile("favorites.txt");
 if(file.existsAsFile())favourites.addLines(file.loadFileAsString());
}
void Freedom2Editor::setBrowserVisible(bool visible){
 browserVisible=visible;
 browserButton.setButtonText(visible?"CLOSE BROWSER":"PRESET BROWSER");
 for(auto* comp:{static_cast<juce::Component*>(&categoryFilter),static_cast<juce::Component*>(&searchBox),static_cast<juce::Component*>(&favouriteButton),static_cast<juce::Component*>(&presetList)})comp->setVisible(visible);
 sectionTitle.setVisible(!visible);
 updatePage();
}
