#pragma once
#include <JuceHeader.h>
#include "FreedomDSP.h"
#include <array>
#include <vector>
class Freedom2Processor final : public juce::AudioProcessor {
public:
  Freedom2Processor();
  void prepareToPlay(double, int) override;
  void releaseResources() override {}
  void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
  bool isBusesLayoutSupported(const BusesLayout&) const override;
  juce::AudioProcessorEditor* createEditor() override;
  bool hasEditor() const override { return true; }
  const juce::String getName() const override { return "Freedom 2"; }
  bool acceptsMidi() const override { return true; }
  bool producesMidi() const override { return false; }
  bool isMidiEffect() const override { return false; }
  double getTailLengthSeconds() const override { return 3.0; }
  int getNumPrograms() override { return 1; }
  int getCurrentProgram() override { return 0; }
  void setCurrentProgram(int) override {}
  const juce::String getProgramName(int) override { return "Init"; }
  void changeProgramName(int, const juce::String&) override {}
  void getStateInformation(juce::MemoryBlock&) override;
  void setStateInformation(const void*, int) override;
  juce::AudioProcessorValueTreeState apvts;
  juce::MidiKeyboardState keyboardState;
private:
  static juce::AudioProcessorValueTreeState::ParameterLayout makeLayout();
  void syncParameters();
  void handleMidi(const juce::MidiMessage&);
  liberty::FreedomDSP dsp;
  std::vector<float> scratchL, scratchR;
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Freedom2Processor)
};
