const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const match=html.match(/<script id="freedom-v70-worklet-source" type="text\/plain">([\s\S]*?)<\/script>/);
assert(match,'AudioWorklet source missing');
let Class;
class Base {constructor(){this.port={onmessage:null,postMessage:(x)=>messages.push(x)}}}
const messages=[];
const context={AudioWorkletProcessor:Base,sampleRate:48000,Float32Array,Map,Set,Math,Number,Object,Array,console,registerProcessor:(name,c)=>{assert.strictEqual(name,'freedom-polyphonic-engine');Class=c}};
vm.runInNewContext(match[1],context,{timeout:2000});
const p=new Class();let passed=0;
function test(name,fn){fn();passed++;console.log('PASS',name)}
function block(n=128){const l=new Float32Array(n),r=new Float32Array(n);assert.strictEqual(p.process([] ,[[l,r]]),true);for(const x of [...l,...r])assert(Number.isFinite(x),'Nonfinite output');return {l,r,peak:Math.max(...l.map(Math.abs),...r.map(Math.abs))}}
function render(n){let peak=0;for(let i=0;i<n;i++)peak=Math.max(peak,block().peak);return peak}
const defaults={'Osc_1_On':1,'Osc_1_Volume':.8,'Osc_1_Wave':0,'Mixer_Osc_1_Level':1,'Osc_2_On':0,'Osc_3_On':0,'Filter_Cutoff':3000,'Filter_Type':0,'Amp_Envelope_Attack':.005,'Amp_Envelope_Decay':.1,'Amp_Envelope_Sustain':.7,'Amp_Envelope_Release':.05,'FX_Chorus_On':0,'FX_Drive_On':0};
p.handle({type:'params',values:defaults});
test('Silence before MIDI',()=>assert.strictEqual(render(4),0));
test('Note on produces finite audio',()=>{p.handle({type:'on',id:'n1',note:60,velocity:110,channel:1});assert(render(20)>0)});
test('Note off releases voice',()=>{p.handle({type:'off',id:'n1'});render(110);assert(!p.voices.has('n1'))});
test('16-voice limit and stealing',()=>{for(let i=0;i<24;i++)p.handle({type:'on',id:'poly'+i,note:48+i,velocity:90,channel:1});assert(p.voices.size<=16);assert(p.steals>=8);assert(render(3)>0)});
test('Panic releases all voices',()=>{p.handle({type:'panic'});render(80);assert.strictEqual(p.voices.size,0)});
test('Sustain CC64 retains and releases',()=>{p.handle({type:'sustain',channel:1,down:true});p.handle({type:'on',id:'sustain',note:64,velocity:95,channel:1});render(4);p.handle({type:'off',id:'sustain'});assert(p.voices.get('sustain').deferred);p.handle({type:'sustain',channel:1,down:false});render(100);assert(!p.voices.has('sustain'))});
test('Rapid retrigger does not duplicate ID',()=>{for(let i=0;i<50;i++)p.handle({type:'on',id:'same',note:65,velocity:90,channel:1});assert.strictEqual(p.voices.size,1);render(3);p.handle({type:'panic'});render(80)});
test('Wave/filter preset transitions are finite',()=>{p.handle({type:'on',id:'change',note:60,velocity:90,channel:1});for(let i=0;i<6;i++){p.handle({type:'params',values:{...defaults,'Osc_1_Wave':i%4,'Filter_Type':i}});render(5)}assert(p.transitionCount>0);p.handle({type:'panic'});render(80)});
test('Chorus and Drive combinations are finite',()=>{p.handle({type:'on',id:'fx',note:72,velocity:90,channel:1});for(const reverse of [0,1]){p.handle({type:'params',values:{...defaults,FX_Chorus_On:1,FX_Drive_On:1,FX_Reverse:reverse,FX_Chorus_Mix:.4,FX_Chorus_Depth:.5,FX_Chorus_Rate:1.1,FX_Drive_Mix:.5,FX_Drive_Amount:.6,FX_Drive_Tone:5000}});render(12)}p.handle({type:'panic'});render(80)});
test('Pitch bend and mod wheel remain finite',()=>{p.handle({type:'on',id:'expression',note:60,velocity:90,channel:1});p.handle({type:'bend',value:1});p.handle({type:'mod',value:1});render(12);p.handle({type:'bend',value:-1});p.handle({type:'mod',value:0});render(12);p.handle({type:'panic'});render(80)});
console.log(`\n${passed} DSP validation scenarios passed. Audio hardware/CPU/underruns not tested.`);
